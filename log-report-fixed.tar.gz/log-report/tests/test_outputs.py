"""Verifier for the log-report task.

Checks /app/report.json against the actual contents of /app/access.log.
Each test corresponds 1:1 to a numbered success criterion in instruction.md.
"""
import json
import re
from collections import Counter
from pathlib import Path

REPORT_PATH = Path("/app/report.json")
LOG_PATH = Path("/app/access.log")


def _expected():
    """Recompute the correct report directly from the log, so the checks
    reflect ground truth rather than a hardcoded value."""
    paths, ips, total = Counter(), set(), 0
    with open(LOG_PATH) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            total += 1
            ips.add(line.split()[0])
            m = re.search(r'"(?:GET|POST|PUT|DELETE|HEAD|PATCH) (\S+) ', line)
            if m:
                paths[m.group(1)] += 1
    return {
        "total_requests": total,
        "unique_ips": len(ips),
        "top_path": paths.most_common(1)[0][0],
    }


def test_report_exists():
    """Criterion 1: /app/report.json exists."""
    assert REPORT_PATH.exists(), "no report.json found at /app/report.json"


def test_report_has_required_keys():
    """Criterion 2: report.json is valid JSON with the required keys."""
    data = json.loads(REPORT_PATH.read_text())
    for key in ("total_requests", "unique_ips", "top_path"):
        assert key in data, f"missing key: {key}"


def test_total_requests_correct():
    """Criterion 3: total_requests matches the actual number of requests."""
    data = json.loads(REPORT_PATH.read_text())
    assert data["total_requests"] == _expected()["total_requests"]


def test_unique_ips_correct():
    """Criterion 4: unique_ips matches the actual number of distinct client IPs."""
    data = json.loads(REPORT_PATH.read_text())
    assert data["unique_ips"] == _expected()["unique_ips"]


def test_top_path_correct():
    """Criterion 5: top_path matches the actual most-requested path."""
    data = json.loads(REPORT_PATH.read_text())
    assert data["top_path"] == _expected()["top_path"]
