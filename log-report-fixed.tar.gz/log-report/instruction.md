There's an access log at /app/access.log. Parse it and write a summary report as
JSON to /app/report.json.

The report must be a single JSON object with exactly these three keys:

- total_requests: the total number of request lines in the log
- unique_ips: the number of distinct client IP addresses that appear in the log
- top_path: the request path (e.g. /index.html) that appears most often

Success criteria:

1. /app/report.json exists.
2. /app/report.json contains valid JSON with the keys total_requests, unique_ips, and top_path.
3. total_requests equals the actual number of requests in /app/access.log.
4. unique_ips equals the actual number of distinct client IPs in /app/access.log.
5. top_path equals the actual most-requested path in /app/access.log.
